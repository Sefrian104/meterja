-- ============================================
-- Database Schema for Water Meter System
-- Updated: Login, Base64 Images, Bill Estimation
-- ============================================

CREATE DATABASE IF NOT EXISTS meteran_db;
USE meteran_db;

-- Users table for login
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    email VARCHAR(100),
    role ENUM('admin', 'user') DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_username (username)
);

-- Devices table
CREATE TABLE IF NOT EXISTS devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(16) UNIQUE NOT NULL,
    name VARCHAR(100),
    location VARCHAR(200),
    api_key VARCHAR(64) UNIQUE,
    is_active BOOLEAN DEFAULT TRUE,
    last_seen TIMESTAMP NULL,
    battery_voltage DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_device_id (device_id)
);

-- Meter readings table (with base64 image backup)
CREATE TABLE IF NOT EXISTS meter_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id INT NOT NULL,
    reading BIGINT NOT NULL,
    confidence DECIMAL(5,4) NOT NULL DEFAULT 0.9500,
    reading_date DATETIME NOT NULL,
    daily_usage DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    bill_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    battery_voltage DECIMAL(5,2),
    -- Base64 image stored as backup
    image_base64 LONGTEXT,
    ocr_method VARCHAR(20) DEFAULT 'TFLITE',
    manual_corrected BOOLEAN DEFAULT FALSE,
    original_reading BIGINT,
    notes TEXT,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE,
    INDEX idx_reading_date (reading_date),
    INDEX idx_device_id (device_id)
);

-- Bill pricing table
CREATE TABLE IF NOT EXISTS bill_pricing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    price_per_m3 DECIMAL(10,2) NOT NULL,
    effective_from DATE NOT NULL,
    effective_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default pricing
INSERT INTO bill_pricing (price_per_m3, effective_from, is_active, notes)
VALUES (3000.00, '2024-01-01', TRUE, 'Tarif default Rp 3.000 per m3');

-- Sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(128) UNIQUE NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (session_token),
    INDEX idx_expires (expires_at)
);

-- Activity log
CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_action (user_id, action),
    INDEX idx_created (created_at)
);

-- Insert default admin user
-- Password: admin123 (hashed with PHP password_hash)
-- This will be created via PHP setup script
INSERT INTO devices (device_id, name, location, api_key)
VALUES
('0016181234567890', 'ESP32-CAM-Meter-01', 'Rumah Utama', 'esp32cam-001-aaaa-bbbb-cccc-dddd-eeee');
