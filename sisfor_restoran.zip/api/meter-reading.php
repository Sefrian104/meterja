<?php
/**
 * Meter Reading API Endpoint (Updated)
 *
 * Receives meter readings from ESP32-CAM with TFLite OCR done on-device.
 * Stores reading + base64 image backup + calculates bill estimation.
 *
 * Usage from ESP32:
 *   POST http://localhost/sisfor_restoran/api/meter-reading.php
 *   Headers:
 *     X-Device-ID: 0016181234567890
 *     X-API-Key: esp32cam-001-aaaa-bbbb-cccc-dddd-eeee
 *   Body (JSON):
 *     {
 *       "reading": 342578,
 *       "confidence": 0.95,
 *       "digits": [3,4,2,5,7,8],
 *       "confidence_per_digit": [0.98,0.97,0.96,0.99,0.94,0.93],
 *       "battery": 3.85,
 *       "image_base64": "/9j/4AAQSkZ...",
 *       "timestamp": 1705312345
 *     }
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Device-ID, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once 'config.php';

// Get device credentials
$deviceId = $_SERVER['HTTP_X_DEVICE_ID'] ?? '';
$apiKey   = $_SERVER['HTTP_X_API_KEY'] ?? '';

// Verify device
$deviceStmt = $pdo->prepare("SELECT id, name FROM devices WHERE device_id = ? AND api_key = ? AND is_active = TRUE LIMIT 1");
$deviceStmt->execute([$deviceId, $apiKey]);
$device = $deviceStmt->fetch();

if (!$device) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid device credentials']);
    exit;
}

$deviceId_db = $device['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Return latest readings for the device
    $stmt = $pdo->prepare("
        SELECT id, reading, confidence, reading_date, daily_usage, bill_amount, battery_voltage, image_base64
        FROM meter_readings
        WHERE device_id = ?
        ORDER BY reading_date DESC
        LIMIT 30
    ");
    $stmt->execute([$deviceId_db]);
    $readings = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'device' => $device,
        'count' => count($readings),
        'readings' => $readings
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Parse JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$reading           = isset($input['reading']) ? intval($input['reading']) : 0;
$confidence        = isset($input['confidence']) ? floatval($input['confidence']) : 0.0;
$digits            = isset($input['digits']) ? $input['digits'] : [];
$confidenceDigits  = isset($input['confidence_per_digit']) ? $input['confidence_per_digit'] : [];
$battery           = isset($input['battery']) ? floatval($input['battery']) : null;
$imageBase64       = isset($input['image_base64']) ? $input['image_base64'] : null;
$timestamp         = isset($input['timestamp']) ? intval($input['timestamp']) : time();

if ($reading <= 0 || $reading > 9999999) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid reading value (must be 1-9999999)']);
    exit;
}

if ($confidence < 0 || $confidence > 1) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid confidence value']);
    exit;
}

try {
    // Get previous reading to calculate daily usage
    $prevStmt = $pdo->prepare("
        SELECT reading, reading_date FROM meter_readings
        WHERE device_id = ? AND reading <= ?
        ORDER BY reading DESC
        LIMIT 1
    ");
    $prevStmt->execute([$deviceId_db, $reading]);
    $prev = $prevStmt->fetch();

    $dailyUsage = 0;
    if ($prev) {
        $dailyUsage = max(0, $reading - $prev['reading']);
    }

    // Get current price
    $pricePerM3 = getCurrentPrice($pdo);
    $billAmount = $dailyUsage * $pricePerM3;

    // Insert reading
    $insertStmt = $pdo->prepare("
        INSERT INTO meter_readings
        (device_id, reading, confidence, reading_date, daily_usage, bill_amount, battery_voltage, image_base64, ocr_method)
        VALUES (?, ?, ?, FROM_UNIXTIME(?), ?, ?, ?, ?, 'TFLITE')
    ");

    $insertStmt->execute([
        $deviceId_db,
        $reading,
        $confidence,
        $timestamp,
        $dailyUsage,
        $billAmount,
        $battery,
        $imageBase64
    ]);

    $readingId = $pdo->insert_id;

    // Update device battery
    if ($battery !== null) {
        $updateDevice = $pdo->prepare("UPDATE devices SET battery_voltage = ?, last_seen = NOW() WHERE id = ?");
        $updateDevice->execute([$battery, $deviceId_db]);
    } else {
        $updateDevice = $pdo->prepare("UPDATE devices SET last_seen = NOW() WHERE id = ?");
        $updateDevice->execute([$deviceId_db]);
    }

    http_response_code(201);
    echo json_encode([
        'success' => true,
        'reading_id' => $readingId,
        'reading' => $reading,
        'digits' => $digits,
        'confidence' => round($confidence, 4),
        'daily_usage' => $dailyUsage,
        'price_per_m3' => $pricePerM3,
        'bill_amount' => $billAmount,
        'timestamp' => date('Y-m-d H:i:s', $timestamp)
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
