<?php
/**
 * Setup script untuk create admin user dan sample user
 * Jalankan sekali untuk initialize: php setup-admin.php
 * atau buka di browser: http://localhost/sisfor_restoran/api/setup-admin.php
 */

require_once 'config.php';

$passwords = [
    'admin' => password_hash('admin123', PASSWORD_DEFAULT),
    'user'  => password_hash('user123', PASSWORD_DEFAULT),
];

try {
    // Insert admin
    $stmt = $pdo->prepare("INSERT IGNORE INTO users (username, password_hash, full_name, email, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['admin', $passwords['admin'], 'Administrator', 'admin@meteran.local', 'admin']);
    echo "✓ Admin user created (username: admin, password: admin123)\n";

    // Insert demo user
    $stmt->execute(['user', $passwords['user'], 'Demo User', 'user@meteran.local', 'user']);
    echo "✓ Demo user created (username: user, password: user123)\n";

    echo "\nSetup complete! You can now login.\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
