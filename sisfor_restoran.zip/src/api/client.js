const API_BASE = (typeof window !== 'undefined' && window.METERAN_API_BASE) || 'http://localhost/sisfor_restoran/api';

function getToken() {
  try { return localStorage.getItem('meteran-token'); } catch { return null; }
}

async function request(path, options = {}) {
  const url = `${API_BASE}${path}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(url, { ...options, headers });
  const text = await res.text();
  let json;
  try { json = text ? JSON.parse(text) : {}; } catch { json = { raw: text }; }
  if (!res.ok && res.status === 401) {
    try { localStorage.removeItem('meteran-token'); localStorage.removeItem('meteran-user'); } catch {}
    if (typeof window !== 'undefined' && window.location && !window.location.pathname.includes('login')) {
      window.location.reload();
    }
  }
  if (!res.ok) {
    const err = new Error(json.error || json.message || `HTTP ${res.status}`);
    err.status = res.status;
    err.body = json;
    throw err;
  }
  return json;
}

export const api = {
  login: (username, password) =>
    request('/login.php', { method: 'POST', body: JSON.stringify({ username, password }) }),

  register: (data) =>
    request('/register.php', { method: 'POST', body: JSON.stringify(data) }),

  me: () =>
    request('/me.php'),

  logout: () =>
    request('/logout.php', { method: 'POST' }),

  getReadings: (limit = 30) =>
    request(`/meter-reading.php?limit=${limit}`),

  getHistory: (days = 60) =>
    request(`/meter-reading.php?days=${days}`),

  getLatest: () =>
    request('/meter-reading.php?latest=1'),

  saveReading: (payload) =>
    request('/meter-reading.php', { method: 'POST', body: JSON.stringify(payload) }),

  getProfile: () =>
    request('/profile.php'),

  updateProfile: (data) =>
    request('/profile.php', { method: 'PUT', body: JSON.stringify(data) }),

  getBill: (month, year) =>
    request(`/bill.php?month=${month}&year=${year}`),
};

export function isAuthenticated() {
  return !!getToken();
}

export function getUser() {
  try {
    const raw = localStorage.getItem('meteran-user');
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
