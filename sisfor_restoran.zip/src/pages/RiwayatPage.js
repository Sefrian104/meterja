import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Filter, Download, Calendar } from 'lucide-react';
import { generateHistoryData } from '../utils/mockData';

const STATUS_COLOR = { Tinggi: '#ff6b6b', Normal: 'var(--accent-cyan)', Rendah: 'var(--accent-green)' };

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-glow)', borderRadius: '8px', padding: '10px 14px', fontFamily: 'var(--font-mono)' }}>
        <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginBottom: '4px' }}>{label}</div>
        <div style={{ fontSize: '18px', color: 'var(--accent-cyan)', fontWeight: '700' }}>{payload[0].value} m³</div>
      </div>
    );
  }
  return null;
};

export default function RiwayatPage() {
  const [filter, setFilter] = useState('semua');
  const [search, setSearch] = useState('');
  const [sortDir, setSortDir] = useState('desc');

  const historyData = useMemo(() => generateHistoryData(30), []);

  const avg = useMemo(() => (historyData.reduce((a, b) => a + b.usage, 0) / historyData.length).toFixed(1), [historyData]);
  const max = useMemo(() => Math.max(...historyData.map(d => d.usage)), [historyData]);
  const min = useMemo(() => Math.min(...historyData.map(d => d.usage)), [historyData]);

  const filtered = useMemo(() => {
    let d = [...historyData];
    if (filter !== 'semua') d = d.filter(x => x.status.toLowerCase() === filter);
    if (search) d = d.filter(x => x.date.includes(search));
    if (sortDir === 'asc') d.sort((a, b) => a.usage - b.usage);
    else if (sortDir === 'desc') d.sort((a, b) => b.usage - a.usage);
    return d;
  }, [historyData, filter, search, sortDir]);

  const chartData = historyData.slice(-14).map(d => ({ ...d, label: d.shortDate }));

  const downloadCSV = () => {
    const header = 'Tanggal,Hari,Pemakaian (m³),Kumulatif (m³),Status\n';
    const rows = historyData.map(d => `${d.date},${d.day},${d.usage},${d.cumulative},${d.status}`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'history-pemakaian.csv'; a.click();
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px', animation: 'fadeIn 0.5s ease' }}>
        <div style={{ fontSize: '10px', color: 'var(--text-muted)', letterSpacing: '0.15em', textTransform: 'uppercase', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>Rekam Jejak</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: '700', color: 'var(--text-primary)' }}>Riwayat Pemakaian</h1>
        <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>Pantau dan analisis histori konsumsi air Anda</p>
      </div>

      {/* Summary stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px', marginBottom: '16px' }}>
        <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '12px', padding: '14px', animation: 'fadeIn 0.5s ease 0.05s both' }}>
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>Rata-rata Harian</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--accent-cyan)' }}>{avg} <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>m³</span></div>
        </div>
        <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '12px', padding: '14px', animation: 'fadeIn 0.5s ease 0.1s both' }}>
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>Tertinggi</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: '#ff6b6b', display: 'flex', alignItems: 'center', gap: '6px' }}>{max} <TrendingUp size={14} /></div>
        </div>
        <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '12px', padding: '14px', animation: 'fadeIn 0.5s ease 0.15s both' }}>
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>Terendah</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--accent-green)', display: 'flex', alignItems: 'center', gap: '6px' }}>{min} <TrendingDown size={14} /></div>
        </div>
        <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '12px', padding: '14px', animation: 'fadeIn 0.5s ease 0.2s both' }}>
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: '6px' }}>Total Bulan</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--accent-teal)' }}>{historyData.reduce((a, b) => a + b.usage, 0)} <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>m³</span></div>
        </div>
      </div>

      {/* Line chart */}
      <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '16px', padding: '16px', marginBottom: '16px', animation: 'fadeIn 0.5s ease 0.25s both' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: '700', color: 'var(--text-primary)' }}>
            Grafik Pemakaian — 14 Hari Terakhir
          </div>
          <button onClick={downloadCSV} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', background: 'rgba(0,212,255,0.08)', border: '1px solid var(--border-glow)', borderRadius: '8px', color: 'var(--accent-cyan)', cursor: 'pointer', fontSize: '10px', fontFamily: 'var(--font-body)' }}>
            <Download size={10} /> Export CSV
          </button>
        </div>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
            <defs>
              <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--accent-cyan)" stopOpacity={0.15} />
                <stop offset="100%" stopColor="var(--accent-cyan)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="label" tick={{ fill: 'var(--text-secondary)', fontSize: 9, fontFamily: 'Space Mono' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'var(--text-secondary)', fontSize: 9, fontFamily: 'Space Mono' }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Line type="monotone" dataKey="usage" stroke="var(--accent-cyan)" strokeWidth={2} fill="url(#lineGrad)" dot={{ fill: 'var(--accent-cyan)', r: 3 }} activeDot={{ r: 5, fill: 'var(--text-primary)', stroke: 'var(--accent-cyan)', strokeWidth: 2 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)', fontSize: '11px' }}>
          <Filter size={11} />
          <span style={{ fontFamily: 'var(--font-mono)' }}>Filter:</span>
        </div>
        {['semua', 'tinggi', 'normal', 'rendah'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            padding: '4px 12px', borderRadius: '20px', fontSize: '10px', fontFamily: 'var(--font-body)', cursor: 'pointer',
            background: filter === f ? 'rgba(0,212,255,0.12)' : 'transparent',
            border: filter === f ? '1px solid var(--border-glow)' : '1px solid var(--border)',
            color: filter === f ? 'var(--accent-cyan)' : 'var(--text-secondary)',
            transition: 'all 0.2s',
            textTransform: 'capitalize',
          }}>{f}</button>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(0,0,0,0.1)', border: '1px solid var(--border)', borderRadius: '8px', padding: '5px 10px' }}>
          <Calendar size={10} color="var(--text-secondary)" />
          <input
            placeholder="Cari..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ background: 'transparent', border: 'none', outline: 'none', color: 'var(--text-primary)', fontSize: '10px', fontFamily: 'var(--font-mono)', width: '80px' }}
          />
        </div>
        <button onClick={() => setSortDir(d => d === 'desc' ? 'asc' : 'desc')} style={{ padding: '5px 10px', background: 'rgba(122,111,255,0.08)', border: '1px solid rgba(122,111,255,0.2)', borderRadius: '8px', color: 'var(--accent-teal)', fontSize: '10px', cursor: 'pointer', fontFamily: 'var(--font-mono)' }}>
          {sortDir === 'desc' ? '↓ Terbesar' : '↑ Terkecil'}
        </button>
      </div>

      {/* Table */}
      <div style={{ background: 'linear-gradient(135deg, var(--bg-card), var(--bg-secondary))', border: '1px solid var(--border)', borderRadius: '16px', overflow: 'hidden', animation: 'fadeIn 0.5s ease 0.35s both', overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '600px' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              {['Tanggal', 'Hari', 'Pemakaian', 'Kumulatif', 'Status'].map(h => (
                <th key={h} style={{ padding: '10px 12px', textAlign: 'left', fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: '400', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((row, i) => (
              <tr key={i} style={{
                borderBottom: '1px solid var(--border)',
                transition: 'background 0.2s',
                animation: `fadeIn 0.3s ease ${i * 0.02}s both`,
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-card-hover)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <td style={{ padding: '10px 12px', fontSize: '11px', fontFamily: 'var(--font-mono)', color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>{row.date}</td>
                <td style={{ padding: '10px 12px', fontSize: '11px', color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{row.day}</td>
                <td style={{ padding: '10px 12px', fontFamily: 'var(--font-display)', fontSize: '14px', color: 'var(--accent-cyan)', whiteSpace: 'nowrap' }}>{row.usage} <span style={{ fontSize: '9px', color: 'var(--text-muted)' }}>m³</span></td>
                <td style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{row.cumulative} m³</td>
                <td style={{ padding: '10px 12px' }}>
                  <span style={{
                    padding: '2px 8px', borderRadius: '20px', fontSize: '9px', fontFamily: 'var(--font-mono)',
                    background: `${STATUS_COLOR[row.status] || '#ff6b6b'}18`,
                    border: `1px solid ${STATUS_COLOR[row.status] || '#ff6b6b'}40`,
                    color: STATUS_COLOR[row.status] || '#ff6b6b',
                  }}>{row.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ padding: '10px 12px', borderTop: '1px solid var(--border)', fontSize: '9px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
          Menampilkan {filtered.length} dari {historyData.length} entri
        </div>
      </div>
    </div>
  );
}
