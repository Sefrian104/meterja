import React, { useState } from 'react';
import { Droplets, Eye, EyeOff, AlertCircle, Loader2 } from 'lucide-react';
import { api, isAuthenticated, getUser } from '../api/client';

export default function LoginPage() {
  const [mode, setMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (isAuthenticated()) {
  return null;
}
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (mode === 'register' && password !== confirmPassword) {
      setError('Password dan konfirmasi tidak cocok');
      return;
    }
    if (password.length < 6) {
      setError('Password minimal 6 karakter');
      return;
    }
    setLoading(true);
    try {
      const data = mode === 'login'
        ? await api.login(username, password)
        : await api.register({ username, password, full_name: fullName, email });
      if (data.token) {
  try {
    localStorage.setItem('meteran-token', data.token);
    localStorage.setItem(
      'meteran-user',
      JSON.stringify(data.user || { username })
    );

    console.log('Token:', localStorage.getItem('meteran-token'));
    console.log('Response:', data);

  } catch (err) {
    console.error(err);
  }

  if (typeof window !== 'undefined') {
    window.location.replace('/');
  }

      } else {
        setError(data.error || 'Login gagal');
      }
    } catch (err) {
      setError(err.message || 'Gagal terhubung ke server');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg-primary)',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'radial-gradient(ellipse 60% 50% at 30% 20%, rgba(0,100,200,0.08) 0%, transparent 60%), radial-gradient(ellipse 40% 40% at 80% 80%, rgba(0,212,255,0.06) 0%, transparent 60%)',
      }} />

      <div style={{
        position: 'relative', zIndex: 1,
        width: '100%', maxWidth: '420px',
        padding: '24px',
      }}>
        <div style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
          borderRadius: '14px',
          padding: '32px',
          boxShadow: 'var(--shadow-glow)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '24px' }}>
            <div style={{
              width: '40px', height: '40px', borderRadius: '10px',
              background: 'linear-gradient(135deg, var(--accent-cyan), var(--accent-blue))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 0 16px rgba(0,212,255,0.3)',
            }}>
              <Droplets size={22} color="#0a0f1e" />
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '16px', fontWeight: '700', color: 'var(--text-primary)' }}>
                SMART WATER METER
              </div>
              <div style={{ fontSize: '10px', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>
                AI-POWERED MONITORING
              </div>
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'var(--text-primary)', marginBottom: '6px' }}>
              {mode === 'login' ? 'Selamat Datang' : 'Daftar Akun'}
            </h1>
            <p style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              {mode === 'login' ? 'Login untuk mengakses dashboard meteran' : 'Buat akun baru untuk mulai memantau'}
            </p>
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {mode === 'register' && (
              <>
                <Field
                  label="Nama Lengkap"
                  value={fullName}
                  onChange={setFullName}
                  placeholder="Nama lengkap"
                  required
                />
                <Field
                  label="Email"
                  type="email"
                  value={email}
                  onChange={setEmail}
                  placeholder="email@example.com"
                  required
                />
              </>
            )}
            <Field
              label="Username"
              value={username}
              onChange={setUsername}
              placeholder="username"
              required
              autoFocus
            />
            <div>
              <label style={labelStyle}>Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{ ...inputStyle, paddingRight: '40px' }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(s => !s)}
                  style={{
                    position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--text-secondary)', padding: '4px',
                  }}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            {mode === 'register' && (
              <Field
                label="Konfirmasi Password"
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={setConfirmPassword}
                placeholder="••••••••"
                required
              />
            )}

            {error && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: '8px',
                padding: '10px 12px', borderRadius: '8px',
                background: 'rgba(255,107,107,0.1)',
                border: '1px solid rgba(255,107,107,0.3)',
                color: '#ff6b6b', fontSize: '12px',
              }}>
                <AlertCircle size={14} />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              style={{
                marginTop: '6px',
                padding: '12px',
                background: loading ? 'var(--bg-card-hover)' : 'linear-gradient(135deg, var(--accent-cyan), var(--accent-blue))',
                color: loading ? 'var(--text-secondary)' : '#0a0f1e',
                border: 'none',
                borderRadius: '8px',
                fontFamily: 'var(--font-display)',
                fontSize: '13px',
                fontWeight: '700',
                letterSpacing: '0.1em',
                cursor: loading ? 'wait' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                boxShadow: loading ? 'none' : '0 0 16px rgba(0,212,255,0.3)',
                transition: 'all 0.2s',
              }}
            >
              {loading && <Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} />}
              {loading ? 'MEMPROSES...' : (mode === 'login' ? 'LOGIN' : 'DAFTAR')}
            </button>
          </form>

          <div style={{
            marginTop: '20px', textAlign: 'center',
            fontSize: '12px', color: 'var(--text-secondary)',
          }}>
            {mode === 'login' ? (
              <>Belum punya akun?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('register'); setError(''); }}
                  style={{ background: 'none', border: 'none', color: 'var(--accent-cyan)', cursor: 'pointer', fontWeight: '600' }}
                >
                  Daftar
                </button>
              </>
            ) : (
              <>Sudah punya akun?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('login'); setError(''); }}
                  style={{ background: 'none', border: 'none', color: 'var(--accent-cyan)', cursor: 'pointer', fontWeight: '600' }}
                >
                  Login
                </button>
              </>
            )}
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '16px', fontSize: '10px', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
          ESP32-CAM · TENSORFLOW LITE · MQTT
        </div>
      </div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

const labelStyle = {
  display: 'block',
  fontSize: '10px',
  color: 'var(--text-secondary)',
  marginBottom: '6px',
  fontFamily: 'var(--font-mono)',
  letterSpacing: '0.1em',
  textTransform: 'uppercase',
};

const inputStyle = {
  width: '100%',
  padding: '10px 12px',
  background: 'var(--bg-secondary)',
  border: '1px solid var(--border)',
  borderRadius: '8px',
  color: 'var(--text-primary)',
  fontSize: '13px',
  fontFamily: 'var(--font-body)',
  outline: 'none',
  transition: 'border 0.2s',
};

function Field({ label, type = 'text', value, onChange, placeholder, required, autoFocus }) {
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        autoFocus={autoFocus}
        style={inputStyle}
      />
    </div>
  );
}
