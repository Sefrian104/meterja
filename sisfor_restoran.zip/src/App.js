import React, { useState, useCallback, useEffect } from 'react';
import './index.css';
import Sidebar from './components/Sidebar';
import DashboardPage from './pages/DashboardPage';
import RiwayatPage from './pages/RiwayatPage';
import KameraPage from './pages/KameraPage';
import TagihanPage from './pages/TagihanPage';
import ProfilePage from './pages/ProfilePage';
import { ThemeProvider } from './utils/ThemeContext';
import AuthGate from './components/AuthGate';
import { api, getUser } from './api/client';

function AppShell() {
  const [page, setPage] = useState('dashboard');
  const [meterDigits, setMeterDigits] = useState([3, 4, 2, 5, 7, 8]);
  const [data, setData] = useState({
    dailyUsage: 0,
    monthlyUsage: 0,
    meterReading: [3, 4, 2, 5, 7, 8],
    weeklyData: [],
    historyData: [],
  });
  const [user, setUser] = useState(getUser());
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    api.getLatest()
      .then((r) => {
        if (r?.reading) {
          const digits = r.reading.digits || (r.reading.meter_value?.toString().padStart(6, '0').split('').map(Number) || [3, 4, 2, 5, 7, 8]);
          setMeterDigits(digits);
          setData((d) => ({ ...d, meterReading: digits, dailyUsage: r.reading.daily_usage || 0, monthlyUsage: r.reading.monthly_usage || 0 }));
        }
      })
      .catch(() => {});
  }, [page]);

  const handleReading = useCallback((result) => {
    if (result?.digits?.length === 6) {
      setMeterDigits(result.digits);
    }
  }, []);

  const handleLogout = useCallback(async () => {
    try { await api.logout(); } catch {}
    try { localStorage.removeItem('meteran-token'); localStorage.removeItem('meteran-user'); } catch {}
    if (typeof window !== 'undefined') window.location.reload();
  }, []);

  const renderPage = () => {
    switch (page) {
      case 'dashboard': return <DashboardPage data={data} meterDigits={meterDigits} onReading={handleReading} />;
      case 'riwayat': return <RiwayatPage />;
      case 'kamera': return <KameraPage meterDigits={meterDigits} onReading={handleReading} />;
      case 'tagihan': return <TagihanPage />;
      case 'profile': return <ProfilePage user={user} onUserUpdate={setUser} onLogout={handleLogout} />;
      default: return null;
    }
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-primary)' }}>
      {/* Ambient background */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        background: 'radial-gradient(ellipse 60% 50% at 30% 20%, rgba(0,100,200,0.06) 0%, transparent 60%), radial-gradient(ellipse 40% 40% at 80% 80%, rgba(0,212,255,0.04) 0%, transparent 60%)',
      }} />

      <Sidebar activePage={page} onNavigate={setPage} isMobile={isMobile} user={user} onLogout={handleLogout} />

      <main style={{
        marginLeft: isMobile ? '0' : '220px',
        marginTop: isMobile ? '57px' : '0',
        flex: 1,
        padding: isMobile ? '16px' : '32px 32px 32px 36px',
        position: 'relative', zIndex: 1,
        maxWidth: isMobile ? '100vw' : 'calc(100vw - 220px)',
        minHeight: '100vh',
      }}>
        {renderPage()}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthGate>
        <AppShell />
      </AuthGate>
    </ThemeProvider>
  );
}
